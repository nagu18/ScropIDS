ScropIDS Agent

Quick Start:
1) Recommended: use the Quick Run Command from the ScropIDS web UI.
   It pre-fills:
   SCROPIDS_API_BASE=https://your-domain/api/v1
   SCROPIDS_ORG_SLUG=your-organization-slug
   SCROPIDS_ORG_ACCESS_TOKEN=your-organization-access-token

2) Run:
   - Linux/macOS: ./scropids-agent
   - Windows: .\scropids-agent.exe

3) If you prefer guided setup:
   - Linux/macOS: ./scropids-agent --setup
   - Windows: .\scropids-agent.exe --setup

The agent auto-enrolls once, then syncs scheduler profile from the server and sends telemetry.
If saved credentials become stale after a backend reset, the agent will try to re-enroll automatically.
