ScropIDS Agent

Quick Start:
1) Set environment:
   SCROPIDS_API_BASE=https://your-domain/api/v1
   SCROPIDS_ORG_SLUG=your-organization-slug
   SCROPIDS_ENROLLMENT_TOKEN=your-one-time-enrollment-token

2) Run:
   - Linux/macOS: ./scropids-agent
   - Windows: .\scropids-agent.exe

The agent enrolls once, then syncs scheduler profile from server and sends telemetry.
